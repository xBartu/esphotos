from django.apps import AppConfig


class AlbumsConfig(AppConfig):
    name = 'albums'