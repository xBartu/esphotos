from .twitter import TwitterAPI
twitter = TwitterAPI()
twitter.walker()